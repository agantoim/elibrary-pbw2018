</br>
			Menu : </br>
			<a href="index.php">Rent</a>
			<span> | </span>
			<a href="info.php">Info</a>
	</body>
</html>