<?php
    function($title,$duration){
        
    }
?>