<?php
class Book{
    $title=" ";
    $author=" ";

    function __Book($title,$author){
        this.$title=$title;
        this.$author=$author;
    }

    function getTitle(){
        this.$title;
    }

    function getAuthor(){
        this.$author;
    }
}
     
?>